# GALERY – GitHub Actions build

Isi ZIP:
- `input.apk`: APK galeri yang kamu kirim.
- `GALERY_icon_transparent.png`: artwork ikon dengan latar hitam luar dibuat transparan.
- `.github/workflows/build.yml`: workflow build APK melalui GitHub Actions.

## Cara build
1. Buat repository GitHub baru.
2. Upload seluruh isi ZIP ini ke repository (termasuk folder `.github`).
3. Buka tab **Actions** → workflow **Build GALERY APK** → **Run workflow**.
4. Setelah selesai, buka hasil run → bagian **Artifacts** → unduh `GALERY-APK`.

## Catatan penting
Workflow ini mengganti resource ikon launcher dan membangun ulang APK. APK yang diberikan adalah hasil kompilasi, bukan source code proyek. Karena itu workflow ini **belum mengubah halaman awal dari Album menjadi Semua Foto**. Perubahan halaman awal membutuhkan source code aplikasi atau konfigurasi internal aplikasi yang dapat diubah dengan aman. Saya tidak menandai fitur itu sebagai selesai.
APK hasil rebuild akan ditandatangani ulang dengan debug key; bila versi lama terpasang, Android mungkin meminta uninstall versi lama sebelum memasang hasil build.
