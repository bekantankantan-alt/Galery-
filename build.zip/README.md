# GALERY — Gaming Dark

Project Android Native (Kotlin) awal untuk Realme Narzo 50i / Android 11.

## Build APK
1. Upload seluruh isi ZIP ke repository GitHub.
2. Buka tab **Actions**.
3. Pilih **Build GALERY APK** lalu tekan **Run workflow** (atau push ke main/master).
4. Setelah selesai, unduh artifact **GALERY-debug**.

## Fitur pada fondasi awal
- Grid media dari penyimpanan perangkat.
- Tab Semua / Foto / Video.
- Thumbnail efisien dengan Glide.
- Foto viewer dan video player dengan kontrol MediaController.
- Bagikan media.
- Permintaan pemindahan ke Trash Android melalui konfirmasi sistem pada Android 11+.
- Icon aplikasi vektor ungu gaming-dark.

## Catatan jujur
Ini adalah fondasi project pertama, belum versi final lengkap. Zoom/crop editor internal, album, favorit, pencarian, daftar Trash di dalam aplikasi, restore dan penghapusan permanen perlu tahap pengembangan berikutnya. Android membatasi akses Trash dan penghapusan media dengan dialog izin sistem. Jangan anggap fitur yang belum tercantum sudah tersedia.
