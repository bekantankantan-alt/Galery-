GALERY X - Android Native

ZIP name: build.zip
Workflow: .github/workflows/build.yml

This revision:
- Uses regular transparent PNG launcher icon resources (no adaptive round icon resource).
- Opens images in an in-app full-screen viewer.
- Loads a higher-resolution source bitmap for sharper viewing (downsampled only above 4096px).
- Supports pinch zoom and horizontal swipe to previous/next media.
- Opens videos in the in-app player with playback controls.

Build:
1. Upload/extract project files to the GitHub repository root.
2. Keep .github/workflows/build.yml in place.
3. Run GitHub Actions workflow and download GALERY-X-APK artifact.
