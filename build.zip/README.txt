GALERY X - BUILD 06
Fixes:
- Trash is now a safe app-managed holding area. Moving to Trash only hides the file from main tabs; it does not delete the original.
- Restore removes the item from the app Trash.
- Permanent delete is a separate explicit action with confirmation and Android system confirmation on Android 11+.
- Image viewer touch routing no longer lets parent swipe container intercept pinch gestures.
- Pinch zoom and double tap remain enabled; image swipe remains handled by image view.
- Video uses Android MediaController with visible play/pause, seek, elapsed/total time, and playback controls; starts with controls shown.
