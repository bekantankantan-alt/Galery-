GALERY X - Android Native

Build:
1. Extract/upload the contents of build.zip into your GitHub repository (keep .github folder).
2. Open Actions > Build GALERY X APK > Run workflow.
3. Download artifact GALERY-X-APK when the workflow completes.

Target: Android 11+ recommended; min SDK 23.
Features: MediaStore image/video browsing, tabs, Android system Trash/restore and permanent delete requests.
Note: Android's launcher may apply its own adaptive icon shape. The source icon artwork has transparent outer background; no circular badge was added by the project.
