GALERY X — BUILD 07
- Trash is app-managed: moving a media item to Trash never deletes the source file.
- Restore removes it from the app Trash list.
- Permanent delete is a separate explicit action with confirmation.
- Image parent container no longer intercepts touch gestures; pinch zoom, double tap, pan and swipe are routed to image view.
- Video uses Android MediaController for play/pause, seek, elapsed and total time; added Stop button that pauses and returns to start.
Workflow unchanged. ZIP filename remains build.zip.
