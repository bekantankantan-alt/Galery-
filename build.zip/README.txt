GALERY X - BUILD 05
Video player additions:
- In-app play/pause, seek bar, current/total time.
- Skip backward/forward 10 seconds.
- Previous/next video navigation.
- Playback speeds: 0.5x, 0.75x, 1.0x, 1.25x, 1.5x, 2.0x.
- Mute/unmute and repeat.
- Horizontal controls strip can be scrolled.
Other image viewer and launcher icon improvements retained.
