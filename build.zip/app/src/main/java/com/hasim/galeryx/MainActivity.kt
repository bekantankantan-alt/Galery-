package com.hasim.galeryx

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ContentUris
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.view.ViewGroup
import android.widget.*
import android.widget.FrameLayout
import kotlin.math.max
import kotlin.math.min

data class MediaItem(val uri: Uri, val name: String, val date: Long, val isVideo: Boolean, val folder: String)

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private lateinit var grid: GridView
    private lateinit var title: TextView
    private lateinit var adapter: MediaAdapter
    private val media = mutableListOf<MediaItem>()
    private var page = "photos"
    private val ink = Color.rgb(27, 28, 33)
    private val muted = Color.rgb(139, 141, 150)
    private val bg = Color.rgb(247, 247, 249)
    private val reqCode = 77

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = Color.WHITE
        if (Build.VERSION.SDK_INT >= 21) window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        buildUi()
        if (hasPermission()) loadMedia() else requestMediaPermission()
    }

    private fun hasPermission(): Boolean = if (Build.VERSION.SDK_INT >= 33) {
        checkSelfPermission(Manifest.permission.READ_MEDIA_IMAGES) == PackageManager.PERMISSION_GRANTED ||
        checkSelfPermission(Manifest.permission.READ_MEDIA_VIDEO) == PackageManager.PERMISSION_GRANTED
    } else checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED

    private fun requestMediaPermission() {
        val p = if (Build.VERSION.SDK_INT >= 33)
            arrayOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO)
        else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        requestPermissions(p, reqCode)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, results)
        if (requestCode == reqCode) {
            if (results.any { it == PackageManager.PERMISSION_GRANTED }) loadMedia()
            else showEmpty("Izinkan akses foto dan video di pengaturan aplikasi.")
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radius).toFloat()
    }
    private fun label(s: String, size: Float, color: Int, bold: Boolean = false) =
        TextView(this).apply {
            text = s; textSize = size; setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    private fun buildUi() {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg) }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(22), dp(20), dp(13))
        }
        title = label("Galeri", 29f, ink, true)
        header.addView(title)
        root.addView(header)

        val tabs = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(2), dp(12), dp(12))
        }
        listOf("Foto" to "photos", "Video" to "videos", "Album" to "albums", "Trash" to "trash").forEach { (name,key) ->
            tabs.addView(tabButton(name,key), LinearLayout.LayoutParams(0, dp(42), 1f))
        }
        root.addView(tabs)

        grid = GridView(this).apply {
            numColumns = 3; horizontalSpacing = dp(3); verticalSpacing = dp(3)
            stretchMode = GridView.STRETCH_COLUMN_WIDTH
            selector = android.graphics.drawable.ColorDrawable(Color.TRANSPARENT)
            setPadding(dp(3), dp(2), dp(3), dp(4))
        }
        adapter = MediaAdapter()
        grid.adapter = adapter
        grid.setOnItemClickListener { _, _, pos, _ -> openViewer(media[pos]) }
        grid.setOnItemLongClickListener { _, _, pos, _ -> itemActions(media[pos]); true }
        root.addView(grid, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun tabButton(name: String, key: String) = label(name, 13f, if (page == key) Color.WHITE else muted, true).apply {
        gravity = Gravity.CENTER
        background = rounded(if (page == key) ink else Color.TRANSPARENT, 22)
        setOnClickListener {
            page = key
            val tabs = root.getChildAt(1) as LinearLayout
            for (i in 0 until tabs.childCount) {
                val v = tabs.getChildAt(i) as TextView
                val k = listOf("photos","videos","albums","trash")[i]
                v.setTextColor(if (k == page) Color.WHITE else muted)
                v.background = rounded(if (k == page) ink else Color.TRANSPARENT,22)
            }
            title.text = when(page) { "videos" -> "Video"; "albums" -> "Album"; "trash" -> "Trash"; else -> "Galeri" }
            loadMedia()
        }
    }

    private fun loadMedia() {
        media.clear()
        if (!hasPermission()) { showEmpty("Izinkan akses foto dan video."); return }
        if (page == "photos" || page == "albums" || page == "trash") queryCollection(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, false)
        if (page == "videos" || page == "albums" || page == "trash") queryCollection(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, true)
        media.sortByDescending { it.date }
        grid.adapter = adapter
        adapter.notifyDataSetChanged()
        if (media.isEmpty()) showEmpty(if(page=="trash") "Trash masih kosong" else "Tidak ada media")
        else grid.visibility = View.VISIBLE
    }

    private fun queryCollection(collection: Uri, video: Boolean) {
        val projection = arrayOf(MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME,
            MediaStore.MediaColumns.DATE_ADDED, MediaStore.MediaColumns.RELATIVE_PATH)
        val selection = if (Build.VERSION.SDK_INT >= 30)
            "${MediaStore.MediaColumns.IS_TRASHED}=${if(page=="trash") 1 else 0}" else null
        try {
            contentResolver.query(collection, projection, selection, null, "${MediaStore.MediaColumns.DATE_ADDED} DESC")?.use { c ->
                val idCol=c.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
                val nameCol=c.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
                val dateCol=c.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_ADDED)
                val pathCol=c.getColumnIndex(MediaStore.MediaColumns.RELATIVE_PATH)
                while(c.moveToNext()) {
                    val id=c.getLong(idCol)
                    media.add(MediaItem(ContentUris.withAppendedId(collection,id),
                        c.getString(nameCol) ?: "Media", c.getLong(dateCol)*1000L, video,
                        if(pathCol>=0) c.getString(pathCol)?.trimEnd('/') ?: "Lainnya" else "Lainnya"))
                }
            }
        } catch (_: Exception) {}
    }

    private fun showEmpty(message: String) {
        grid.adapter = object : BaseAdapter() {
            override fun getCount()=1
            override fun getItem(p:Int):Any=message
            override fun getItemId(p:Int)=0L
            override fun getView(p:Int, old:View?, parent:ViewGroup?)=TextView(this@MainActivity).apply {
                text=message; textSize=15f; setTextColor(muted); gravity=Gravity.CENTER
                setPadding(dp(24),dp(70),dp(24),dp(70))
            }
        }
    }

    private inner class MediaAdapter : BaseAdapter() {
        override fun getCount()=media.size
        override fun getItem(p:Int)=media[p]
        override fun getItemId(p:Int)=p.toLong()
        override fun getView(position:Int, convertView:View?, parent:ViewGroup?):View {
            val image=(convertView as? ImageView) ?: ImageView(this@MainActivity).apply {
                scaleType=ImageView.ScaleType.CENTER_CROP
                setBackgroundColor(0xFFE9E9ED.toInt())
            }
            image.layoutParams=AbsListView.LayoutParams(-1,dp(116))
            image.setImageDrawable(null)
            try {
                if(Build.VERSION.SDK_INT>=29) {
                    val bmp=contentResolver.loadThumbnail(media[position].uri, android.util.Size(dp(220),dp(220)), null)
                    image.setImageBitmap(bmp)
                } else image.setImageURI(media[position].uri)
            } catch (_:Exception) {
                try { image.setImageURI(media[position].uri) } catch (_:Exception) {
                    image.setImageResource(android.R.drawable.ic_menu_gallery)
                }
            }
            return image
        }
    }

    private fun openViewer(item: MediaItem) {
        val overlay = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        val close = TextView(this).apply {
            text="‹"; textSize=34f; setTextColor(Color.WHITE); gravity=Gravity.CENTER
            setPadding(dp(12),dp(4),dp(12),dp(4))
        }
        val info = TextView(this).apply {
            text=item.name; textSize=13f; setTextColor(Color.WHITE); gravity=Gravity.CENTER_VERTICAL
            setPadding(dp(60),0,dp(60),0); maxLines=1
        }
        val top = FrameLayout(this)
        top.addView(info, FrameLayout.LayoutParams(-1,dp(54)))
        top.addView(close,FrameLayout.LayoutParams(dp(54),dp(54),Gravity.LEFT or Gravity.TOP))
        overlay.addView(top,FrameLayout.LayoutParams(-1,dp(54),Gravity.TOP))
        val dialog = android.app.Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen)
        if(item.isVideo) {
            val video=VideoView(this)
            video.setVideoURI(item.uri)
            val controller=MediaController(this); controller.setAnchorView(video); video.setMediaController(controller)
            overlay.addView(video,FrameLayout.LayoutParams(-1,-1))
            video.setOnPreparedListener { mp -> mp.isLooping=false; video.start() }
        } else {
            val zoom=ZoomImageView(this)
            try {
                if(Build.VERSION.SDK_INT>=29) zoom.setImageBitmap(contentResolver.loadThumbnail(item.uri,android.util.Size(1800,1800),null))
                else zoom.setImageURI(item.uri)
            } catch (_:Exception) { zoom.setImageURI(item.uri) }
            overlay.addView(zoom,FrameLayout.LayoutParams(-1,-1))
        }
        close.setOnClickListener { dialog.dismiss() }
        val bottom=LinearLayout(this).apply {
            gravity=Gravity.CENTER; setPadding(0,dp(10),0,dp(18))
            val action=TextView(this@MainActivity).apply {
                text=if(page=="trash") "Pulihkan" else "Hapus"; textSize=14f; setTextColor(Color.WHITE)
                setPadding(dp(24),dp(12),dp(24),dp(12)); background=rounded(0x55333333,24)
                setOnClickListener { itemActions(item); dialog.dismiss() }
            }
            addView(action)
        }
        overlay.addView(bottom,FrameLayout.LayoutParams(-1,dp(68),Gravity.BOTTOM))
        top.bringToFront()
        bottom.bringToFront()
        dialog.setContentView(overlay)
        dialog.show()
    }

    private inner class ZoomImageView(ctx: android.content.Context) : ImageView(ctx) {
        private val matrixValue=Matrix()
        private val detector=ScaleGestureDetector(ctx, object:ScaleGestureDetector.SimpleOnScaleGestureListener(){
            override fun onScale(detector:ScaleGestureDetector):Boolean {
                matrixValue.postScale(detector.scaleFactor,detector.scaleFactor,detector.focusX,detector.focusY)
                imageMatrix=matrixValue; return true
            }
        })
        init {
            scaleType=ScaleType.MATRIX
            setOnTouchListener { _, event -> detector.onTouchEvent(event); true }
        }
        override fun onSizeChanged(w:Int,h:Int,oldw:Int,oldh:Int) {
            super.onSizeChanged(w,h,oldw,oldh)
            val d=drawable ?: return
            val scale=min(w.toFloat()/d.intrinsicWidth.toFloat(), h.toFloat()/d.intrinsicHeight.toFloat())
            val dx=(w-d.intrinsicWidth*scale)/2f
            val dy=(h-d.intrinsicHeight*scale)/2f
            matrixValue.setScale(scale,scale)
            matrixValue.postTranslate(dx,dy)
            imageMatrix=matrixValue
        }
    }

    private fun itemActions(item:MediaItem) {
        val options=if(page=="trash") arrayOf("Pulihkan dari Trash","Hapus permanen","Batal")
                    else arrayOf("Pindahkan ke Trash","Buka","Batal")
        AlertDialog.Builder(this).setItems(options){_,which->
            when {
                page=="trash" && which==0 -> changeTrash(item,false)
                page=="trash" && which==1 -> deletePermanently(item)
                page!="trash" && which==0 -> changeTrash(item,true)
                page!="trash" && which==1 -> openViewer(item)
            }
        }.show()
    }

    private fun changeTrash(item:MediaItem, trash:Boolean) {
        if(Build.VERSION.SDK_INT>=30) try {
            val request=MediaStore.createTrashRequest(contentResolver,listOf(item.uri),trash)
            startIntentSenderForResult(request.intentSender,91,null,0,0,0)
        } catch(_:Exception) { Toast.makeText(this,"Tidak dapat mengubah Trash",Toast.LENGTH_SHORT).show() }
        else Toast.makeText(this,"Trash sistem tersedia pada Android 11 ke atas",Toast.LENGTH_SHORT).show()
    }
    private fun deletePermanently(item:MediaItem) {
        if(Build.VERSION.SDK_INT>=30) try {
            val request=MediaStore.createDeleteRequest(contentResolver,listOf(item.uri))
            startIntentSenderForResult(request.intentSender,92,null,0,0,0)
        } catch(_:Exception) { Toast.makeText(this,"Tidak dapat menghapus media",Toast.LENGTH_SHORT).show() }
    }
    @Deprecated("Android callback")
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?) {
        super.onActivityResult(requestCode,resultCode,data)
        if(requestCode==91 || requestCode==92) loadMedia()
    }
    override fun onResume(){ super.onResume(); if(::adapter.isInitialized && hasPermission()) loadMedia() }
}
