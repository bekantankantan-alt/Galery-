package com.hasim.galeryx

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ContentUris
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.BitmapFactory
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.view.ViewGroup
import android.widget.*
import android.widget.FrameLayout
import kotlin.math.max
import kotlin.math.min
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.common.MediaItem as PlayerMediaItem

data class MediaItem(val uri: Uri, val name: String, val date: Long, val isVideo: Boolean, val folder: String)

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private lateinit var grid: GridView
    private lateinit var title: TextView
    private lateinit var adapter: MediaAdapter
    private val media = mutableListOf<MediaItem>()
    private var page = "photos"
    private val ink = Color.rgb(27, 28, 33)
    private val muted = Color.rgb(139, 141, 150)
    private val bg = Color.rgb(247, 247, 249)
    private val reqCode = 77
    private var viewerItems: List<MediaItem> = emptyList()
    private var viewerIndex: Int = 0
    private var activeViewerDialog: android.app.Dialog? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = Color.WHITE
        if (Build.VERSION.SDK_INT >= 21) window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        buildUi()
        if (hasPermission()) loadMedia() else requestMediaPermission()
    }

    private fun hasPermission(): Boolean = if (Build.VERSION.SDK_INT >= 33) {
        checkSelfPermission(Manifest.permission.READ_MEDIA_IMAGES) == PackageManager.PERMISSION_GRANTED ||
        checkSelfPermission(Manifest.permission.READ_MEDIA_VIDEO) == PackageManager.PERMISSION_GRANTED
    } else checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED

    private fun requestMediaPermission() {
        val p = if (Build.VERSION.SDK_INT >= 33)
            arrayOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO)
        else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        requestPermissions(p, reqCode)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, results)
        if (requestCode == reqCode) {
            if (results.any { it == PackageManager.PERMISSION_GRANTED }) loadMedia()
            else showEmpty("Izinkan akses foto dan video di pengaturan aplikasi.")
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radius).toFloat()
    }
    private fun label(s: String, size: Float, color: Int, bold: Boolean = false) =
        TextView(this).apply {
            text = s; textSize = size; setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    private fun buildUi() {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg) }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(22), dp(20), dp(13))
        }
        title = label("Galeri", 29f, ink, true)
        header.addView(title)
        root.addView(header)

        val tabs = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(2), dp(12), dp(12))
        }
        listOf("Foto" to "photos", "Video" to "videos", "Album" to "albums", "Trash" to "trash").forEach { (name,key) ->
            tabs.addView(tabButton(name,key), LinearLayout.LayoutParams(0, dp(42), 1f))
        }
        root.addView(tabs)

        grid = GridView(this).apply {
            numColumns = 3; horizontalSpacing = dp(3); verticalSpacing = dp(3)
            stretchMode = GridView.STRETCH_COLUMN_WIDTH
            selector = android.graphics.drawable.ColorDrawable(Color.TRANSPARENT)
            setPadding(dp(3), dp(2), dp(3), dp(4))
        }
        adapter = MediaAdapter()
        grid.adapter = adapter
        grid.setOnItemClickListener { _, _, pos, _ -> openViewer(media[pos]) }
        grid.setOnItemLongClickListener { _, _, pos, _ -> itemActions(media[pos]); true }
        root.addView(grid, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun tabButton(name: String, key: String) = label(name, 13f, if (page == key) Color.WHITE else muted, true).apply {
        gravity = Gravity.CENTER
        background = rounded(if (page == key) ink else Color.TRANSPARENT, 22)
        setOnClickListener {
            page = key
            val tabs = root.getChildAt(1) as LinearLayout
            for (i in 0 until tabs.childCount) {
                val v = tabs.getChildAt(i) as TextView
                val k = listOf("photos","videos","albums","trash")[i]
                v.setTextColor(if (k == page) Color.WHITE else muted)
                v.background = rounded(if (k == page) ink else Color.TRANSPARENT,22)
            }
            title.text = when(page) { "videos" -> "Video"; "albums" -> "Album"; "trash" -> "Trash"; else -> "Galeri" }
            loadMedia()
        }
    }

    private fun loadMedia() {
        media.clear()
        if (!hasPermission()) { showEmpty("Izinkan akses foto dan video."); return }
        if (page == "photos" || page == "albums" || page == "trash") queryCollection(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, false)
        if (page == "videos" || page == "albums" || page == "trash") queryCollection(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, true)
        media.sortByDescending { it.date }
        grid.adapter = adapter
        adapter.notifyDataSetChanged()
        if (media.isEmpty()) showEmpty(if(page=="trash") "Trash masih kosong" else "Tidak ada media")
        else grid.visibility = View.VISIBLE
    }

    private fun queryCollection(collection: Uri, video: Boolean) {
        val projection = arrayOf(MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME,
            MediaStore.MediaColumns.DATE_ADDED, MediaStore.MediaColumns.RELATIVE_PATH)
        try {
            contentResolver.query(collection, projection, null, null, "${MediaStore.MediaColumns.DATE_ADDED} DESC")?.use { c ->
                val idCol=c.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
                val nameCol=c.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
                val dateCol=c.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_ADDED)
                val pathCol=c.getColumnIndex(MediaStore.MediaColumns.RELATIVE_PATH)
                while(c.moveToNext()) {
                    val id=c.getLong(idCol)
                    val uri = ContentUris.withAppendedId(collection,id)
                    val isTrashed = getSharedPreferences("galeryx_trash", MODE_PRIVATE)
                        .getStringSet("items", emptySet())!!.contains(uri.toString())
                    if ((page == "trash") != isTrashed) continue
                    media.add(MediaItem(uri,
                        c.getString(nameCol) ?: "Media", c.getLong(dateCol)*1000L, video,
                        if(pathCol>=0) c.getString(pathCol)?.trimEnd('/') ?: "Lainnya" else "Lainnya"))
                }
            }
        } catch (_: Exception) {}
    }

    private fun showEmpty(message: String) {
        grid.adapter = object : BaseAdapter() {
            override fun getCount()=1
            override fun getItem(p:Int):Any=message
            override fun getItemId(p:Int)=0L
            override fun getView(p:Int, old:View?, parent:ViewGroup?)=TextView(this@MainActivity).apply {
                text=message; textSize=15f; setTextColor(muted); gravity=Gravity.CENTER
                setPadding(dp(24),dp(70),dp(24),dp(70))
            }
        }
    }

    private inner class MediaAdapter : BaseAdapter() {
        override fun getCount()=media.size
        override fun getItem(p:Int)=media[p]
        override fun getItemId(p:Int)=p.toLong()
        override fun getView(position:Int, convertView:View?, parent:ViewGroup?):View {
            val image=(convertView as? ImageView) ?: ImageView(this@MainActivity).apply {
                scaleType=ImageView.ScaleType.CENTER_CROP
                setBackgroundColor(0xFFE9E9ED.toInt())
            }
            image.layoutParams=AbsListView.LayoutParams(-1,dp(116))
            image.setImageDrawable(null)
            try {
                if(Build.VERSION.SDK_INT>=29) {
                    val bmp=contentResolver.loadThumbnail(media[position].uri, android.util.Size(dp(220),dp(220)), null)
                    image.setImageBitmap(bmp)
                } else image.setImageURI(media[position].uri)
            } catch (_:Exception) {
                try { image.setImageURI(media[position].uri) } catch (_:Exception) {
                    image.setImageResource(android.R.drawable.ic_menu_gallery)
                }
            }
            return image
        }
    }

    private fun openViewer(item: MediaItem) {
        viewerItems = media.toList()
        viewerIndex = viewerItems.indexOfFirst { it.uri == item.uri }.coerceAtLeast(0)
        showViewerItem(item)
    }

    private fun showViewerItem(item: MediaItem) {
        activeViewerDialog?.dismiss()
        activeViewerDialog = null
        val overlay = SwipeFrameLayout(this) { direction ->
            val next = viewerIndex + direction
            if (next in viewerItems.indices) {
                viewerIndex = next
                showViewerItem(viewerItems[viewerIndex])
            }
        }.apply { setBackgroundColor(Color.BLACK) }

        val close = TextView(this).apply {
            text = "‹"
            textSize = 42f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = rounded(0x99000000.toInt(), 36)
            isClickable = true
            isFocusable = true
            elevation = dp(18).toFloat()
            contentDescription = "Kembali ke galeri"
            setOnClickListener {
                (overlay.tag as? android.app.Dialog)?.dismiss()
                activeViewerDialog = null
            }
        }
        val info = TextView(this).apply {
            text=item.name; textSize=13f; setTextColor(Color.WHITE); gravity=Gravity.CENTER_VERTICAL
            setPadding(dp(60),0,dp(60),0); maxLines=1
        }
        val top = FrameLayout(this)
        top.addView(info, FrameLayout.LayoutParams(-1,dp(54)))
        top.addView(close,FrameLayout.LayoutParams(dp(64),dp(64),Gravity.LEFT or Gravity.TOP))
        overlay.addView(top,FrameLayout.LayoutParams(-1,dp(68),Gravity.TOP))

        val dialog = android.app.Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen)
        activeViewerDialog = dialog
        overlay.tag = dialog

        if(item.isVideo) {
            // TextureView-backed Media3 player avoids many SurfaceView layering issues
            // that can cause a black video area in dialogs on some Android devices.
            val videoTexture = android.view.TextureView(this).apply {
                setBackgroundColor(Color.BLACK)
            }
            overlay.addView(videoTexture, FrameLayout.LayoutParams(-1, -1))
            val player = ExoPlayer.Builder(this).build()
            player.setVideoTextureView(videoTexture)
            val controls = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(18), dp(12), dp(18), dp(12))
                background = rounded(0xDD171717.toInt(), 18)
                elevation = dp(24).toFloat()
            }
            val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
            val playPause = TextView(this).apply {
                text = "Ⅱ  Jeda"; textSize = 15f; setTextColor(Color.WHITE)
                setPadding(dp(12), dp(8), dp(16), dp(8)); isClickable = true
            }
            val elapsed = label("00:00", 12f, Color.WHITE)
            val duration = label("00:00", 12f, Color.WHITE)
            val seek = SeekBar(this).apply { max = 1000; progress = 0 }
            row.addView(playPause)
            row.addView(elapsed)
            controls.addView(row)
            controls.addView(seek, LinearLayout.LayoutParams(-1, dp(34)))
            val timeRow = LinearLayout(this).apply { gravity = Gravity.RIGHT }
            timeRow.addView(duration)
            controls.addView(timeRow)
            overlay.addView(controls, FrameLayout.LayoutParams(-1, dp(112), Gravity.BOTTOM).apply {
                leftMargin = dp(12); rightMargin = dp(12); bottomMargin = dp(76)
            })

            var tracking = false
            val handler = android.os.Handler(mainLooper)
            val tick = object : Runnable {
                override fun run() {
                    val d = player.duration.takeIf { it > 0 } ?: 0L
                    val pos = player.currentPosition.coerceAtLeast(0L)
                    if (!tracking && d > 0) seek.progress = ((pos.toFloat() / d) * 1000).toInt()
                    elapsed.text = formatTime(pos.toInt())
                    if (d > 0) duration.text = formatTime(d.toInt())
                    if (dialog.isShowing) handler.postDelayed(this, 350)
                }
            }
            playPause.setOnClickListener {
                if (player.isPlaying) player.pause() else player.play()
            }
            player.addListener(object : Player.Listener {
                override fun onPlaybackStateChanged(state: Int) {
                    if (state == Player.STATE_READY) {
                        duration.text = formatTime(player.duration.coerceAtLeast(0L).toInt())
                        handler.removeCallbacks(tick)
                        handler.post(tick)
                    }
                }
                override fun onIsPlayingChanged(isPlaying: Boolean) {
                    playPause.text = if (isPlaying) "Ⅱ  Jeda" else "▶  Putar"
                }
                override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                    playPause.text = "▶  Coba lagi"
                    Toast.makeText(this@MainActivity, "Video tidak didukung atau gagal dibuka: ${error.errorCodeName}", Toast.LENGTH_LONG).show()
                }
            })
            seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(bar: SeekBar?, value: Int, fromUser: Boolean) {
                    if (fromUser && player.duration > 0) elapsed.text = formatTime((player.duration * value / 1000).toInt())
                }
                override fun onStartTrackingTouch(bar: SeekBar?) { tracking = true }
                override fun onStopTrackingTouch(bar: SeekBar?) {
                    if (player.duration > 0) player.seekTo(player.duration * seek.progress / 1000)
                    tracking = false
                }
            })
            player.setMediaItem(PlayerMediaItem.fromUri(item.uri))
            player.prepare()
            player.playWhenReady = true
            dialog.setOnDismissListener {
                handler.removeCallbacks(tick)
                player.clearVideoTextureView(videoTexture)
                player.release()
                if (activeViewerDialog === dialog) activeViewerDialog = null
            }
        } else {
            val zoom=ZoomImageView(this)
            zoom.scaleType=ImageView.ScaleType.FIT_CENTER
            zoom.setBackgroundColor(Color.BLACK)
            zoom.loadOriginal(item.uri)
            overlay.addView(zoom,FrameLayout.LayoutParams(-1,-1))
        }

        val bottom=LinearLayout(this).apply {
            gravity=Gravity.CENTER; setPadding(0,dp(10),0,dp(18))
            val action=TextView(this@MainActivity).apply {
                text=if(page=="trash") "Pulihkan" else "Hapus"; textSize=14f; setTextColor(Color.WHITE)
                setPadding(dp(24),dp(12),dp(24),dp(12)); background=rounded(0x55333333,24)
                setOnClickListener { itemActions(item); dialog.dismiss(); activeViewerDialog = null }
            }
            addView(action)
        }
        overlay.addView(bottom,FrameLayout.LayoutParams(-1,dp(68),Gravity.BOTTOM))
        top.isClickable = true
        top.bringToFront()
        bottom.bringToFront()
        dialog.setContentView(overlay)
        dialog.setCanceledOnTouchOutside(false)
        dialog.setOnKeyListener { _, keyCode, event ->
            if (keyCode == android.view.KeyEvent.KEYCODE_BACK && event.action == android.view.KeyEvent.ACTION_UP) {
                dialog.dismiss()
                activeViewerDialog = null
                true
            } else false
        }
        dialog.show()
        top.bringToFront()
        close.bringToFront()
        bottom.bringToFront()
    }

    private inner class SwipeFrameLayout(ctx: android.content.Context, val onSwipe:(Int)->Unit) : FrameLayout(ctx) {
        // Never steal touch events from the image. Horizontal paging is handled by
        // ZoomImageView only while the image is at its fitted scale.
        override fun onInterceptTouchEvent(ev: MotionEvent): Boolean = false
    }

    private inner class ZoomImageView(ctx: android.content.Context) : ImageView(ctx) {
        private val imageMatrixValue = Matrix()
        private val scaleDetector = ScaleGestureDetector(ctx, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(detector: ScaleGestureDetector): Boolean {
                val old = currentScale
                val target = (old * detector.scaleFactor).coerceIn(minScale, 5.0f)
                val factor = target / old
                imageMatrixValue.postScale(factor, factor, detector.focusX, detector.focusY)
                currentScale = target
                constrainMatrix()
                imageMatrix = imageMatrixValue
                return true
            }
        })
        private val gestureDetector = android.view.GestureDetector(ctx, object : android.view.GestureDetector.SimpleOnGestureListener() {
            override fun onDoubleTap(e: MotionEvent): Boolean {
                if (currentScale > minScale + 0.05f) {
                    fitImage()
                } else {
                    val target = 3.0f
                    val factor = target / currentScale
                    imageMatrixValue.postScale(factor, factor, e.x, e.y)
                    currentScale = target
                    constrainMatrix()
                    imageMatrix = imageMatrixValue
                }
                return true
            }
            override fun onDown(e: MotionEvent): Boolean = true
        })
        private var currentScale = 1.0f
        private var minScale = 1.0f
        private var lastX = 0f
        private var lastY = 0f
        private var dragging = false
        private var downX = 0f
        private var downY = 0f
        private var didPan = false

        init {
            scaleType = ScaleType.MATRIX
            isClickable = true
            setOnTouchListener { view, event ->
                parent?.requestDisallowInterceptTouchEvent(true)
                gestureDetector.onTouchEvent(event)
                scaleDetector.onTouchEvent(event)
                when (event.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        downX = event.x
                        downY = event.y
                        lastX = event.x
                        lastY = event.y
                        dragging = true
                        didPan = false
                    }
                    MotionEvent.ACTION_MOVE -> {
                        if (dragging && currentScale > minScale + 0.01f && event.pointerCount == 1) {
                            val dx = event.x - lastX
                            val dy = event.y - lastY
                            imageMatrixValue.postTranslate(dx, dy)
                            constrainMatrix()
                            imageMatrix = imageMatrixValue
                            didPan = true
                        }
                        lastX = event.x
                        lastY = event.y
                    }
                    MotionEvent.ACTION_UP -> {
                        parent?.requestDisallowInterceptTouchEvent(false)
                        val dx = event.x - downX
                        val dy = event.y - downY
                        if (!didPan && currentScale <= minScale + 0.01f &&
                            kotlin.math.abs(dx) > dp(75) && kotlin.math.abs(dx) > kotlin.math.abs(dy) * 1.4f) {
                            val next = viewerIndex + if (dx < 0) 1 else -1
                            if (next in viewerItems.indices) {
                                viewerIndex = next
                                showViewerItem(viewerItems[viewerIndex])
                            }
                        }
                        dragging = false
                    }
                    MotionEvent.ACTION_CANCEL -> { dragging = false; parent?.requestDisallowInterceptTouchEvent(false) }
                }
                true
            }
        }

        fun loadOriginal(uri: Uri) {
            Thread {
                try {
                    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                    contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
                    var sample = 1
                    while (maxOf(bounds.outWidth, bounds.outHeight) / sample > 4096) sample *= 2
                    val opts = BitmapFactory.Options().apply {
                        inSampleSize = sample
                        inPreferredConfig = android.graphics.Bitmap.Config.ARGB_8888
                    }
                    val bitmap = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
                    runOnUiThread {
                        if (bitmap != null) {
                            setImageBitmap(bitmap)
                            post { fitImage() }
                        } else setImageURI(uri)
                    }
                } catch (_: Exception) {
                    runOnUiThread { setImageURI(uri); post { fitImage() } }
                }
            }.start()
        }

        private fun constrainMatrix() {
            val d = drawable ?: return
            val rect = android.graphics.RectF(0f, 0f, d.intrinsicWidth.toFloat(), d.intrinsicHeight.toFloat())
            imageMatrixValue.mapRect(rect)
            var dx = 0f
            var dy = 0f
            dx = if (rect.width() <= width) (width - rect.width()) / 2f - rect.left
                 else if (rect.left > 0f) -rect.left else if (rect.right < width) width - rect.right else 0f
            dy = if (rect.height() <= height) (height - rect.height()) / 2f - rect.top
                 else if (rect.top > 0f) -rect.top else if (rect.bottom < height) height - rect.bottom else 0f
            imageMatrixValue.postTranslate(dx, dy)
        }

        private fun fitImage() {
            val d = drawable ?: return
            if (width <= 0 || height <= 0 || d.intrinsicWidth <= 0 || d.intrinsicHeight <= 0) return
            val scale = min(width.toFloat() / d.intrinsicWidth.toFloat(), height.toFloat() / d.intrinsicHeight.toFloat())
            val dx = (width - d.intrinsicWidth * scale) / 2f
            val dy = (height - d.intrinsicHeight * scale) / 2f
            imageMatrixValue.reset()
            imageMatrixValue.setScale(scale, scale)
            imageMatrixValue.postTranslate(dx, dy)
            minScale = 1.0f
            currentScale = minScale
            imageMatrix = imageMatrixValue
        }

        override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
            super.onSizeChanged(w, h, oldw, oldh)
            post { fitImage() }
        }
    }

    private fun formatTime(ms: Int): String {
        val total = (ms / 1000).coerceAtLeast(0)
        return String.format(java.util.Locale.US, "%02d:%02d", total / 60, total % 60)
    }

    private fun itemActions(item:MediaItem) {
        val options=if(page=="trash") arrayOf("Pulihkan dari Trash","Hapus permanen","Batal")
                    else arrayOf("Pindahkan ke Trash","Buka","Batal")
        AlertDialog.Builder(this).setItems(options){_,which->
            when {
                page=="trash" && which==0 -> changeTrash(item,false)
                page=="trash" && which==1 -> deletePermanently(item)
                page!="trash" && which==0 -> changeTrash(item,true)
                page!="trash" && which==1 -> openViewer(item)
            }
        }.show()
    }

    private fun changeTrash(item:MediaItem, trash:Boolean) {
        val prefs = getSharedPreferences("galeryx_trash", MODE_PRIVATE)
        val items = prefs.getStringSet("items", emptySet())?.toMutableSet() ?: mutableSetOf()
        if (trash) items.add(item.uri.toString()) else items.remove(item.uri.toString())
        prefs.edit().putStringSet("items", items).apply()
        Toast.makeText(this, if (trash) "Dipindahkan ke Trash" else "Dipulihkan", Toast.LENGTH_SHORT).show()
        loadMedia()
    }
    private fun deletePermanently(item:MediaItem) {
        AlertDialog.Builder(this)
            .setTitle("Hapus permanen?")
            .setMessage("${item.name} akan dihapus dari perangkat dan tidak bisa dipulihkan.")
            .setNegativeButton("Batal", null)
            .setPositiveButton("Hapus") { _, _ ->
                try {
                    if (Build.VERSION.SDK_INT >= 30) {
                        val request = MediaStore.createDeleteRequest(contentResolver, listOf(item.uri))
                        startIntentSenderForResult(request.intentSender, 92, null, 0, 0, 0)
                    } else {
                        val deleted = contentResolver.delete(item.uri, null, null)
                        if (deleted > 0) {
                            val prefs = getSharedPreferences("galeryx_trash", MODE_PRIVATE)
                            val items = prefs.getStringSet("items", emptySet())?.toMutableSet() ?: mutableSetOf()
                            items.remove(item.uri.toString())
                            prefs.edit().putStringSet("items", items).apply()
                            Toast.makeText(this, "Media dihapus permanen", Toast.LENGTH_SHORT).show()
                            loadMedia()
                        } else Toast.makeText(this, "Media tidak terhapus", Toast.LENGTH_SHORT).show()
                    }
                } catch (e: android.app.RecoverableSecurityException) {
                    startIntentSenderForResult(e.userAction.actionIntent.intentSender, 92, null, 0, 0, 0)
                } catch (e: SecurityException) {
                    Toast.makeText(this, "Android meminta izin tambahan untuk menghapus media", Toast.LENGTH_LONG).show()
                } catch (_: Exception) {
                    Toast.makeText(this, "Tidak dapat menghapus media", Toast.LENGTH_SHORT).show()
                }
            }.show()
    }
    @Deprecated("Android callback")
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?) {
        super.onActivityResult(requestCode,resultCode,data)
        if(requestCode==91 || requestCode==92) loadMedia()
    }
    override fun onResume(){ super.onResume(); if(::adapter.isInitialized && hasPermission()) loadMedia() }
}
