package com.hasim.galeryx

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ContentUris
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable

data class MediaItem(val uri: Uri, val name: String, val date: Long, val isVideo: Boolean, val trashed: Boolean)

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private lateinit var grid: GridView
    private lateinit var title: TextView
    private lateinit var subtitle: TextView
    private lateinit var adapter: MediaAdapter
    private val media = mutableListOf<MediaItem>()
    private var page = "photos"
    private val ink = Color.rgb(27, 28, 33)
    private val muted = Color.rgb(139, 141, 150)
    private val bg = Color.rgb(247, 247, 249)
    private val card = Color.WHITE
    private val reqCode = 77

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = Color.WHITE
        if (Build.VERSION.SDK_INT >= 21) {
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        }
        buildUi()
        if (hasPermission()) loadMedia() else requestMediaPermission()
    }

    private fun hasPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= 33) {
            checkSelfPermission(Manifest.permission.READ_MEDIA_IMAGES) == PackageManager.PERMISSION_GRANTED ||
            checkSelfPermission(Manifest.permission.READ_MEDIA_VIDEO) == PackageManager.PERMISSION_GRANTED
        } else checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
    }

    private fun requestMediaPermission() {
        val permissions = if (Build.VERSION.SDK_INT >= 33)
            arrayOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO)
        else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        requestPermissions(permissions, reqCode)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, results)
        if (requestCode == reqCode) {
            if (results.any { it == PackageManager.PERMISSION_GRANTED }) loadMedia()
            else showEmpty("Izin foto dan video diperlukan agar GALERY X bisa menampilkan media.")
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun rounded(color: Int, radius: Int): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }

    private fun text(value: String, size: Float, color: Int, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = value; textSize = size; setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    private fun buildUi() {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg) }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(20), dp(20), dp(10))
        }
        title = text("Galeri", 29f, ink, true)
        subtitle = text("Semua kenanganmu, di satu tempat", 13f, muted)
        header.addView(title)
        header.addView(subtitle)
        root.addView(header)

        val tabs = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(4), dp(16), dp(12))
        }
        tabs.addView(tabButton("Foto", "photos"), LinearLayout.LayoutParams(0, dp(42), 1f))
        tabs.addView(tabButton("Video", "videos"), LinearLayout.LayoutParams(0, dp(42), 1f))
        tabs.addView(tabButton("Album", "albums"), LinearLayout.LayoutParams(0, dp(42), 1f))
        tabs.addView(tabButton("Trash", "trash"), LinearLayout.LayoutParams(0, dp(42), 1f))
        root.addView(tabs)

        grid = GridView(this).apply {
            numColumns = 3
            horizontalSpacing = dp(3); verticalSpacing = dp(3)
            stretchMode = GridView.STRETCH_COLUMN_WIDTH
            selector = android.graphics.drawable.ColorDrawable(Color.TRANSPARENT)
            setPadding(dp(3), dp(2), dp(3), dp(8))
        }
        adapter = MediaAdapter()
        grid.adapter = adapter
        grid.setOnItemClickListener { _, _, position, _ -> openItem(media[position]) }
        grid.setOnItemLongClickListener { _, _, position, _ -> itemActions(media[position]); true }
        root.addView(grid, LinearLayout.LayoutParams(-1, 0, 1f))

        val bottom = LinearLayout(this).apply {
            setBackgroundColor(Color.WHITE); gravity = Gravity.CENTER
            setPadding(dp(12), dp(9), dp(12), dp(10))
        }
        val hint = text("GALERY X  •  Tekan foto untuk melihat  •  Tahan untuk opsi", 11f, muted)
        hint.gravity = Gravity.CENTER
        bottom.addView(hint)
        root.addView(bottom)
        setContentView(root)
    }

    private fun tabButton(label: String, key: String): TextView {
        return text(label, 13f, if (page == key) Color.WHITE else muted, true).apply {
            gravity = Gravity.CENTER
            background = rounded(if (page == key) ink else Color.TRANSPARENT, 22)
            setOnClickListener { page = key; updateTabs(); loadMedia() }
        }
    }

    private fun updateTabs() {
        // Rebuild tab strip with active state.
        val tabs = root.getChildAt(1) as LinearLayout
        val names = listOf("Foto" to "photos", "Video" to "videos", "Album" to "albums", "Trash" to "trash")
        tabs.removeAllViews()
        names.forEach { (label, key) -> tabs.addView(tabButton(label, key), LinearLayout.LayoutParams(0, dp(42), 1f)) }
        title.text = when(page) { "videos" -> "Video"; "albums" -> "Album"; "trash" -> "Trash"; else -> "Galeri" }
        subtitle.text = when(page) { "trash" -> "Media yang kamu pindahkan ke Trash"; "albums" -> "Jelajahi berdasarkan folder"; else -> "Semua kenanganmu, di satu tempat" }
    }

    private fun loadMedia() {
        media.clear()
        if (!hasPermission()) { showEmpty("Berikan izin akses foto dan video."); return }
        val collectionImages = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        val collectionVideos = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        if (page == "photos" || page == "albums" || page == "trash") queryCollection(collectionImages, false)
        if (page == "videos" || page == "albums" || page == "trash") queryCollection(collectionVideos, true)
        media.sortByDescending { it.date }
        adapter.notifyDataSetChanged()
        if (media.isEmpty()) showEmpty(if (page == "trash") "Trash masih kosong" else "Belum ada foto atau video")
        else grid.visibility = View.VISIBLE
    }

    private fun queryCollection(collection: Uri, video: Boolean) {
        val projection = arrayOf(MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME, MediaStore.MediaColumns.DATE_ADDED)
        val selection: String?
        val args: Array<String>?
        if (Build.VERSION.SDK_INT >= 30) {
            selection = if (page == "trash") "${MediaStore.MediaColumns.IS_TRASHED}=1" else "${MediaStore.MediaColumns.IS_TRASHED}=0"
            args = null
        } else { selection = null; args = null }
        try {
            contentResolver.query(collection, projection, selection, args, "${MediaStore.MediaColumns.DATE_ADDED} DESC")?.use { c ->
                val idCol = c.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
                val nameCol = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
                val dateCol = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_ADDED)
                while (c.moveToNext()) {
                    val id = c.getLong(idCol)
                    val uri = ContentUris.withAppendedId(collection, id)
                    media.add(MediaItem(uri, c.getString(nameCol) ?: "Media", c.getLong(dateCol) * 1000L, video, page == "trash"))
                }
            }
        } catch (_: Exception) { }
    }

    private fun showEmpty(message: String) {
        grid.visibility = View.VISIBLE
        grid.adapter = object : android.widget.BaseAdapter() {
            override fun getCount() = 1
            override fun getItem(position: Int): Any = message
            override fun getItemId(position: Int) = 0L
            override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
                return TextView(this@MainActivity).apply {
                    text = "✧\n\n$message"
                    textSize = 15f; setTextColor(muted); gravity = Gravity.CENTER
                    setPadding(dp(28), dp(75), dp(28), dp(75))
                }
            }
        }
    }

    private inner class MediaAdapter : android.widget.BaseAdapter() {
        override fun getCount() = media.size
        override fun getItem(position: Int) = media[position]
        override fun getItemId(position: Int) = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val image = (convertView as? ImageView) ?: ImageView(this@MainActivity).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                background = rounded(0xFFE9E9ED.toInt(), 8)
            }
            image.layoutParams = AbsListView.LayoutParams(-1, dp(116))
            try {
                if (Build.VERSION.SDK_INT >= 29) image.setImageBitmap(contentResolver.loadThumbnail(media[position].uri, android.util.Size(dp(160), dp(160)), null))
                else image.setImageURI(media[position].uri)
            } catch (_: Exception) { image.setImageResource(android.R.drawable.ic_menu_gallery) }
            return image
        }
    }

    private fun openItem(item: MediaItem) {
        if (page == "albums") {
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(item.uri, if (item.isVideo) "video/*" else "image/*")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            try { startActivity(intent) } catch (_: Exception) { Toast.makeText(this, "Tidak ada aplikasi pembuka media", Toast.LENGTH_SHORT).show() }
            return
        }
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(item.uri, if (item.isVideo) "video/*" else "image/*")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        try { startActivity(intent) } catch (_: Exception) { Toast.makeText(this, "Tidak bisa membuka media", Toast.LENGTH_SHORT).show() }
    }

    private fun itemActions(item: MediaItem) {
        val options = if (page == "trash") arrayOf("Pulihkan dari Trash", "Hapus permanen", "Batal")
                      else arrayOf("Pindahkan ke Trash", "Buka media", "Batal")
        AlertDialog.Builder(this).setTitle(item.name).setItems(options) { _, which ->
            when {
                page == "trash" && which == 0 -> requestTrash(item, false)
                page == "trash" && which == 1 -> requestDelete(item)
                page != "trash" && which == 0 -> requestTrash(item, true)
                page != "trash" && which == 1 -> openItem(item)
            }
        }.show()
    }

    private fun requestTrash(item: MediaItem, trash: Boolean) {
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                val pending = MediaStore.createTrashRequest(contentResolver, listOf(item.uri), trash)
                @Suppress("DEPRECATION")
                startIntentSenderForResult(pending.intentSender, 91, null, 0, 0, 0)
            } catch (e: Exception) { Toast.makeText(this, "Tidak dapat mengubah status Trash", Toast.LENGTH_LONG).show() }
        } else {
            Toast.makeText(this, "Trash Android memerlukan Android 11 atau lebih baru", Toast.LENGTH_LONG).show()
        }
    }

    private fun requestDelete(item: MediaItem) {
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                val pending = MediaStore.createDeleteRequest(contentResolver, listOf(item.uri))
                @Suppress("DEPRECATION")
                startIntentSenderForResult(pending.intentSender, 92, null, 0, 0, 0)
            } catch (_: Exception) { Toast.makeText(this, "Tidak dapat menghapus media", Toast.LENGTH_SHORT).show() }
        } else {
            AlertDialog.Builder(this).setMessage("Hapus media permanen?").setPositiveButton("Hapus") { _, _ ->
                try { contentResolver.delete(item.uri, null, null); loadMedia() } catch (_: Exception) {}
            }.setNegativeButton("Batal", null).show()
        }
    }

    @Deprecated("Deprecated by Android")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 91 || requestCode == 92) loadMedia()
    }

    override fun onResume() { super.onResume(); if (::adapter.isInitialized && hasPermission()) loadMedia() }
}
