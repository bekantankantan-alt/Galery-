package com.hasim.galery

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Button
import android.widget.ImageView
import android.widget.MediaController
import android.widget.VideoView
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide

class ViewerActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_viewer)
        val uri = Uri.parse(intent.getStringExtra("uri") ?: return)
        val isVideo = intent.getBooleanExtra("video", false)
        val photo = findViewById<ImageView>(R.id.photo)
        val video = findViewById<VideoView>(R.id.video)
        if (isVideo) {
            photo.visibility = android.view.View.GONE
            video.visibility = android.view.View.VISIBLE
            video.setVideoURI(uri)
            video.setMediaController(MediaController(this).apply { setAnchorView(video) })
            video.setOnPreparedListener { it.start() }
        } else {
            Glide.with(this).load(uri).into(photo)
        }
        findViewById<Button>(R.id.deleteBtn).setOnClickListener {
            try {
                if (android.os.Build.VERSION.SDK_INT >= 30) {
                    val request = MediaStore.createTrashRequest(contentResolver, listOf(uri), true)
                    @Suppress("DEPRECATION")
                    startIntentSenderForResult(request.intentSender, 20, null, 0, 0, 0)
                } else {
                    @Suppress("DEPRECATION")
                    startActivityForResult(Intent(Intent.ACTION_DELETE, uri), 20)
                }
            } catch (_: Exception) { finish() }
        }
        findViewById<Button>(R.id.shareBtn).setOnClickListener {
            val share = Intent(Intent.ACTION_SEND).apply {
                type = if (isVideo) "video/*" else "image/*"
                putExtra(Intent.EXTRA_STREAM, uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(share, "Bagikan"))
        }
        findViewById<Button>(R.id.cropBtn).setOnClickListener {
            if (!isVideo) {
                val crop = Intent("com.android.camera.action.CROP").apply {
                    setDataAndType(uri, "image/*"); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                try { startActivity(crop) } catch (_: Exception) {
                    android.widget.Toast.makeText(this, "Editor crop tidak tersedia di perangkat ini.", android.widget.Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
}
