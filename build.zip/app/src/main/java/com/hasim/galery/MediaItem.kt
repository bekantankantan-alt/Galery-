package com.hasim.galery

import android.net.Uri

data class MediaItem(val uri: Uri, val isVideo: Boolean, val name: String)
