package com.hasim.galery

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.database.Cursor
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.tabs.TabLayout
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    private lateinit var grid: RecyclerView
    private lateinit var count: TextView
    private lateinit var empty: TextView
    private var mode = 0
    private val items = mutableListOf<MediaItem>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        grid = findViewById(R.id.grid)
        count = findViewById(R.id.countText)
        empty = findViewById(R.id.emptyText)
        grid.layoutManager = GridLayoutManager(this, 3)
        val tabs = findViewById<TabLayout>(R.id.tabs)
        listOf("Semua", "Foto", "Video").forEach { tabs.addTab(tabs.newTab().setText(it)) }
        tabs.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab) { mode = tab.position; loadMedia() }
            override fun onTabUnselected(tab: TabLayout.Tab) {}
            override fun onTabReselected(tab: TabLayout.Tab) {}
        })
        if (hasPermission()) loadMedia() else requestPermission()
    }

    private fun hasPermission(): Boolean {
        val permissions = if (Build.VERSION.SDK_INT >= 33)
            arrayOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO)
        else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        return permissions.all { ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED }
    }

    private fun requestPermission() {
        val permissions = if (Build.VERSION.SDK_INT >= 33)
            arrayOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO)
        else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        ActivityCompat.requestPermissions(this, permissions, 10)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 10 && hasPermission()) loadMedia()
    }

    private fun loadMedia() {
        if (!hasPermission()) return
        items.clear()
        val collections = when (mode) {
            1 -> listOf(MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
            2 -> listOf(MediaStore.Video.Media.EXTERNAL_CONTENT_URI)
            else -> listOf(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, MediaStore.Video.Media.EXTERNAL_CONTENT_URI)
        }
        for (collection in collections) {
            val isVideo = collection == MediaStore.Video.Media.EXTERNAL_CONTENT_URI
            val projection = arrayOf(MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME)
            val sort = "${MediaStore.MediaColumns.DATE_ADDED} DESC"
            contentResolver.query(collection, projection, null, null, sort)?.use { c ->
                val idCol = c.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
                val nameCol = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
                while (c.moveToNext()) {
                    val id = c.getLong(idCol)
                    val uri = android.content.ContentUris.withAppendedId(collection, id)
                    items.add(MediaItem(uri, isVideo, c.getString(nameCol) ?: ""))
                }
            }
        }
        items.sortByDescending { it.uri.toString() }
        grid.adapter = MediaAdapter(items) { item ->
            startActivity(Intent(this, ViewerActivity::class.java).apply {
                putExtra("uri", item.uri.toString()); putExtra("video", item.isVideo)
            })
        }
        count.text = "${items.size} item"
        empty.visibility = if (items.isEmpty()) android.view.View.VISIBLE else android.view.View.GONE
    }
}
